from flask import Flask, request, flash, url_for, redirect, render_template
from flask_sqlalchemy import SQLAlchemy
app = Flask(__name__)
app.config['SQLALCHEMY_DATABASE_URI'] = 'postgresql://postgres:kgisl@localhost/vehicle'
app.config['SECRET_KEY'] = "random string"
db = SQLAlchemy(app)
@app.route('/login')
def login():
   return render_template("login.html")
@app.route('/reg')
def reg():
   return render_template("index.html")
@app.route('/wel')
def welcome():
   return render_template("wel.html") 
@app.route('/system')
def wcs():
   return render_template("system.html")  
@app.route('/wws')
def wws():
   return render_template("wws.html")      
if __name__ == '__main__':
   app.run(debug = True)

class register(db.Model):
	id = db.Column('customer_id', db.Integer, primary_key = True)
	name = db.Column(db.String(100))
	email = db.Column(db.String(100))
	username = db.Column(db.String(200)) 
	password = db.Column(db.String(100))
	repassword = db.Column(db.String(100))
	birthmonth = db.Column(db.String(100))
	birthday = db.Column(db.String(100))
	birthyear = db.Column(db.String(100))
	phone = db.Column(db.String(100))
	def __init__(self, name, email, username,password,repassword,birthmonth,birthday,birthyear,phone):
		self.name = name
		self.email = email
		self.username = username
		self.password = password
		self.repasswod = repassword
		self.birthmonth = birthmonth
		self.birthday = birthday
		self.birthyear = birthyear
		self.phone = phone
	@app.route('/index', methods = ['GET', 'POST'])
	def new1():
		if request.method == 'POST':
			if not request.form['name'] or not request.form['email'] or not request.form['username'] or not request.form['password'] or not request.form['repassword'] or not request.form['birthmonth'] or not request.form['birthday'] or not request.form['birthyear'] or not request.form['phone']:
				flash('Please enter all the fields', 'error')
			else:
				customer_id = register(request.form['name'], request.form['email'],request.form['username'],request.form['password'],request.form['repassword'],request.form['birthmonth'], request.form['birthday'], request.form['birthyear'], request.form['phone'])
				db.session.add(customer_id)
				db.session.commit()
				flash('Record was successfully added')
				return redirect(url_for('wel'))
				return render_template('index.html')
if __name__ == '__main__':
	db.create_all()
	app.run(debug = True)
