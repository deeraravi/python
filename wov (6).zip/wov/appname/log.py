from flask import Flask, request, flash, url_for, redirect, render_template
from flask_sqlalchemy import SQLAlchemy
app = Flask(__name__)
app.config['SQLALCHEMY_DATABASE_URI'] = 'postgresql://postgres:kgisl@localhost/vehicle'
app.config['SECRET_KEY'] = "random string"

db = SQLAlchemy(app)

@app.route('/login')
def login():
	return render_template("login.html")
@app.route('/welcome/<name>')
def welcome(name):
	return render_template("demo.html",register=register.query.filter_by(username='%s'%name)) 
@app.route('/reg')
def register():
	return render_template("index.html")
@app.route('/home')
def home():
	return render_template("wel.html")
@app.route('/system')
def system():
	return render_template("system.html") 
@app.route('/weight')
def weight():
	return render_template("weight.html") 
@app.route('/vreg')
def vregister():
	return render_template("vreg.html",register=register.query.all())
@app.route('/vweight')
def vweight():
	return render_template("vweight.html",weight=weight.query.all()) 
	
@app.route('/weight_det/<Model>')
def weight_det(Model):
	return render_template("weight_detail.html",weight=weight.query.filter_by(Models='%s'%Model)) 
@app.route('/wws')
def wws():
	return render_template("wws.html") 

@app.route('/search_detail/<name>')
def search_detail(name):
	return render_template("search_view.html",register=register.query.filter_by(username='%s'%name)) 
@app.route('/logout')
def logout():
	return render_template("login.html")      
class register(db.Model):
		id = db.Column('customers_id', db.Integer, primary_key = True)
		name = db.Column(db.String(200))
		email = db.Column(db.String(100))
		username = db.Column(db.String(200)) 
		password = db.Column(db.String(100))
		repassword = db.Column(db.String(100))
		birthmonth = db.Column(db.String(100))
		birthday = db.Column(db.String(100))
		birthyear = db.Column(db.String(100))
		phone = db.Column(db.String(100))
		def __init__(self, name, email, username,password,repassword,birthmonth,birthday,birthyear,phone):
			self.name = name
			self.email = email
			self.username = username
			self.password = password
			self.repasswod = repassword
			self.birthmonth = birthmonth
			self.birthday = birthday
			self.birthyear = birthyear
			self.phone = phone
		@app.route('/login', methods = ['GET', 'POST'])
		def new():
			if request.method == 'POST':
				if not request.form['name'] or not request.form['email'] or not request.form['username'] or not request.form['password'] or not request.form['repassword'] or not request.form['birthmonth'] or not request.form['birthday'] or not request.form['birthyear'] or not request.form['phone']:
					flash('Please enter all the fields', 'error')
				else:
					customers = register(request.form['name'], request.form['email'],request.form['username'],request.form['password'],request.form['repassword'],request.form['birthmonth'], request.form['birthday'], request.form['birthyear'], request.form['phone'])
					db.session.add(customers)
					db.session.commit()
					flash('Record was successfully added')
					return redirect(url_for('register'))
			return render_template('index.html')
@app.route('/wel', methods=['POST','GET'])
def wel():
	if request.method=='GET':
		return render_template('login.html')
	username = request.form['username']
	password = request.form['password']
	customers=register.query.filter_by(username=username,password=password).first()
	if request.form['password'] == 'admin' and request.form['username'] == 'admin':
		return render_template("admin.html")
	if customers is None:
		return render_template("login.html")
	else:
		return redirect(url_for('welcome',name=username))
@app.route('/search', methods=['POST','GET'])
def search_view():
	if request.method=='GET':
		return render_template('search.html')
	search = request.form['search']
 	return redirect(url_for('search_detail',name=search))


class weight(db.Model):
	id = db.Column('demo_id', db.Integer, primary_key = True)
	Brand = db.Column(db.String(100))
	Models = db.Column(db.String(200)) 
  	Kilograms = db.Column(db.String(100))
	def __init__(self,Brand,Models,Kilograms):
		self.Brand = Brand
		self.Models = Models
		self.Kilograms = Kilograms
	@app.route('/login', methods = ['GET', 'POST'])
	def new1():
			if request.method == 'POST':
				if not request.form['Brand'] or not request.form['Models'] or not request.form['Kilograms']:
					flash('Please enter all the fields', 'error')
				else:
					demo = weight(request.form['Brand'], request.form['Models'],request.form['Kilograms'])
					db.session.add(demo)
					db.session.commit()
					flash('Record was successfully added')
					return redirect(url_for('weight'))
			return render_template('weight.html')
@app.route('/weight_view', methods=['POST','GET'])
def weight_detail():
	if request.method=='GET':
		return render_template('weight_view.html')
	search = request.form['Brand']
	search_1 = request.form['Model']
 	return redirect(url_for('weight_det',Brand=search,Model=search_1))
		
if __name__ == '__main__':
	db.create_all()
	app.run(debug = True)
