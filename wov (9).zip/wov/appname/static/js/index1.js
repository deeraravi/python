$('.btn').on('click', function () {
    $('.form').addClass('form--no');
});