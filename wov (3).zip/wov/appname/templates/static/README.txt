A Pen created at CodePen.io. You can find this one at http://codepen.io/iamnbutler/pen/clrDk.

 http://dribbble.com/shots/1361746-BANANAPLATE-Login-panel?list=users